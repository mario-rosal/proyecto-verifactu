# Tests de regresión
- Cada bug cerrado añade un test que fallaba antes y pasa después.
- Nombrar como `issue-<id>-<desc>.test.ts` o `test_issue_<id>.ts`.
- Ubicación aquí o en la carpeta estándar del proyecto.
