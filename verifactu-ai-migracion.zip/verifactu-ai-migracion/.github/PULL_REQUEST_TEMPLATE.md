## Qué cambia y por qué
(Resumen funcional y técnico breve)

## Plan del asistente (si hubo IA)
(Pasos, riesgos, alcance)

## Evidencias
- Logs de CI
- Capturas o casos manuales

## Tests añadidos / regresión
(archivos y escenarios)
