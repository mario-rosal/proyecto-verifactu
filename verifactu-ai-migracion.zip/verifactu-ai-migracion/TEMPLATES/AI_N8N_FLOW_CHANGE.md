# PROMPT — Cambio de flujo n8n

**Flujo**: <nombre>
**Objetivo**: <qué y por qué>
**Entradas/Salidas**: <datos>
**Contratos afectados**: <BFF/Connector/API>

**Entrega**
1) PLAN (nodos afectados, variables, errores)
2) Export JSON del flujo actualizado (ponerlo en `/flows/<name>.json`)
3) Changelog del flujo (README)
