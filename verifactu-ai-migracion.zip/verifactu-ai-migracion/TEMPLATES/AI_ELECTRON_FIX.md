# PROMPT — Fix en Electron (chokidar/electron-store)

**Bug/Mejora**: <descr.>
**Ruta observada**: <path>
**Config schema**: <keys>

**Criterios**
- [ ] No bloquear hilo principal
- [ ] Validar permisos y existencia de la carpeta
- [ ] Tests de unidad para utilidades de FS/config

**Fases**: PLAN → `git diff` con fix + test
